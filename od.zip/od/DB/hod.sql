-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2018 at 09:38 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hod`
--

-- --------------------------------------------------------

--
-- Table structure for table `appr`
--

CREATE TABLE `appr` (
  `regno` varchar(10) NOT NULL,
  `dtfrm` date NOT NULL,
  `dtto` date NOT NULL,
  `appr` text NOT NULL,
  `time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appr`
--

INSERT INTO `appr` (`regno`, `dtfrm`, `dtto`, `appr`, `time`) VALUES
('', '0000-00-00', '0000-00-00', '', '2018-04-11 14:49:09.349197'),
('', '0000-00-00', '0000-00-00', '', '2018-04-11 14:49:44.090700'),
('15cs037', '2018-04-02', '2018-04-03', 'APROVED', '2018-04-11 14:49:57.452557'),
('15cs037', '2018-04-02', '2018-04-03', 'CANCLED', '2018-04-11 14:50:25.292665'),
('', '0000-00-00', '0000-00-00', '', '2018-04-11 14:51:05.626670'),
('', '0000-00-00', '0000-00-00', '', '2018-04-11 16:23:48.606147');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `uname` text NOT NULL,
  `pass` varchar(50) NOT NULL,
  `dep` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`uname`, `pass`, `dep`) VALUES
('cse', 'cse', 'csce'),
('ece', 'ece', 'ece');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
