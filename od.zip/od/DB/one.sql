-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2018 at 09:38 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `one`
--

-- --------------------------------------------------------

--
-- Table structure for table `appr`
--

CREATE TABLE `appr` (
  `regno` varchar(50) NOT NULL,
  `dtfrm` date NOT NULL,
  `dtto` date NOT NULL,
  `appr` text NOT NULL,
  `time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appr`
--

INSERT INTO `appr` (`regno`, `dtfrm`, `dtto`, `appr`, `time`) VALUES
('', '0000-00-00', '0000-00-00', '', '2018-04-11 16:25:22.099228'),
('', '0000-00-00', '0000-00-00', '', '2018-04-11 16:25:23.811506'),
('15cs037', '2018-04-10', '2018-04-11', 'APROVED', '2018-04-11 16:25:56.593858'),
('15cs037', '2018-04-26', '2018-04-23', 'PENDING', '2018-04-11 16:26:39.560743'),
('', '0000-00-00', '0000-00-00', '', '2018-04-12 18:09:17.330226');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `id` varchar(20) NOT NULL,
  `dep` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `phno` int(12) NOT NULL,
  `pass1` varchar(50) NOT NULL,
  `pass2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`fname`, `lname`, `id`, `dep`, `email`, `phno`, `pass1`, `pass2`) VALUES
('', '', '', '', '', 0, '', ''),
('0', 'e', '0', 'AUTO', 'e', 3, 'e', 'e'),
('guna', 's', '15cs032', 'CSE', 'guna@gmail.com', 98, 'guna', 'guna'),
('hari', 's', '15cs037', 'CSE', 'g@gmail.com', 98, 'hari', 'hari'),
('divya', 'mau', '33', 'BIO', 'jhgh@gmail.com', 47841659, 'pp', 'pp'),
('q', 'q', 'q3', 'AUTO', '3', 3, '3', '3'),
('v', 'v', 'v', 'E&I', 'v', 4, '4', '4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
