-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2018 at 09:39 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `two`
--

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `fname` text NOT NULL,
  `id` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phno` int(12) NOT NULL,
  `pass1` varchar(50) NOT NULL,
  `pass2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`fname`, `id`, `email`, `phno`, `pass1`, `pass2`) VALUES
('', '', '', 0, '', ''),
('a', '0', 'e', 3, 'a', 'a'),
('q', '1', 'q', 1, '1', '1'),
('hani', '15', 'hanigobhhuy', 0, 'hani', 'hani'),
('guna', '15cs032', 'guna', 98, 'guna', 'guna'),
('hari', '15cs037', 'hari@gmail.com', 98, 'hari', 'hari'),
('kartik', '15cs049', 'kk@gmail.com', 57463215, 'kkr', 'kkr'),
('d', 'd', 'd', 3, 'd', 'd'),
('q', 'q', 'q', 9, 'q', 'q'),
('r', 'r', 'r', 9, 'r', 'r');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
