<?php
 
$conn = mysqli_connect('127.0.0.1','root','');
	
	
	if(!$conn)
	
	{
		echo 'not connected to server';
	}

	if(!mysqli_select_db($conn,'two'))
	{
		echo 'No db selected';	
	}


$id = $_GET['id'];

$sql = "SELECT `fname`, `id`, `degree`, `dep`, `year`, `sec`, `batch`, `od`, `tname`, `clgname`, `dtfrm`, `dtto`, `reqod`, `ws`, `ppt`, `tevent`, `ntevent`, `conf`, `sport`, `plink` FROM `stufrm1` WHERE id='$id'";
$result = $conn->query($sql);
//$rowcount =  mysqli_num_rows($result);
if($result-> num_rows > 0)
{
echo '<span style=" color:#fff">';
echo '<table border="2">';
echo '<tr>';
echo '<th><font color="#fff">NAME</th>';
echo '<th><font color="#fff">ID</th>';
echo '<th><font color="#fff">YEAR</th>';
echo '<th><font color="#fff">SEC</th>';
echo '<th><font color="#fff">AVAILED OD</th>';
echo '<th><font color="#fff">TUTOR NAME</th>';
echo '<th><font color="#fff">COLLEGE NAME</th>';
echo '<th><font color="#fff">FROM</th>';
echo '<th><font color="#fff">TO</th>';
echo '<th><font color="#fff">REQ OD</th>';
echo '<th><font color="#fff">WORK-SHOP</th>';
echo '<th><font color="#fff">PPT</th>';
echo '<th><font color="#fff">TECH EVENT</th>';
echo '<th><font color="#fff">NON-TECH EVENT</th>';
echo '<th><font color="#fff">CONFERENCE</th>';
echo '<th><font color="#fff">SPORT</th>';
echo '<th><font color="#fff">POSTER LINK</th>';
echo '</tr>';
while($row = $result->fetch_assoc())
{
echo "<tr>";
echo '<td><font color="#fff">'.$row['fname'].'</td>';
echo '<td><font color="#fff">'.$row['id'].'</td>';
echo '<td><font color="#fff">'.$row['year'].'</td>';
echo '<td><font color="#fff">'.$row['sec'].'</td>';
echo '<td><font color="#fff">'.$row['od'].'</td>';
echo '<td><font color="#fff">'.$row['tname'].'</td>';
echo '<td><font color="#fff">'.$row['clgname'].'</td>';
echo '<td><font color="#fff">'.$row['dtfrm'].'</td>';
echo '<td><font color="#fff">'.$row['dtto'].'</td>';
echo '<td><font color="#fff">'.$row['reqod'].'</td>';
echo '<td><font color="#fff">'.$row['ws'].'</td>';
echo '<td><font color="#fff">'.$row['ppt'].'</td>';
echo '<td><font color="#fff">'.$row['tevent'].'</td>';
echo '<td><font color="#fff">'.$row['ntevent'].'</td>';
echo '<td><font color="#fff">'.$row['conf'].'</td>';
echo '<td><font color="#fff">'.$row['sport'].'</td>';
echo '<td><font color="#fff">'.$row['plink'].'</td>';
echo "</tr>";
}
}
else
{
 echo "sorry no match found";
 header("Refresh:1; url=../hodsearch.html");
}
$conn->close();
 ?>