<?php
 
$conn = mysqli_connect('127.0.0.1','root','');
	
	
	if(!$conn)
	
	{
		echo 'not connected to server';
	}

	if(!mysqli_select_db($conn,'one'))
	{
		echo 'No db selected';	
	}


$regno = $_GET['regno'];

$sql = "SELECT `regno`, `dtfrm`, `dtto`, `appr` FROM `appr` WHERE regno='$regno'";
$result = $conn->query($sql);
//$rowcount =  mysqli_num_rows($result);
if($result-> num_rows > 0)
{
echo "<center>";
echo '<table border="2">';
echo "<tr>";
echo '<th><font color="#fff">REG NO</th>';
echo '<th><font color="#fff">DATE FROM</th>';
echo '<th><font color="#fff">DATE TO</th>';
echo '<th><font color="#fff">CONFIRMATION</th>';
echo "</tr>";
while($row = $result->fetch_assoc())
{
echo "<center>";
echo "<tr>";
echo '<td><font color="#fff">'.$row['regno'].'</td>';
echo '<td><font color="#fff">'.$row['dtfrm'].'</td>';
echo '<td><font color="#fff">'.$row['dtto'].'</td>';
echo '<td><font color="#fff">'.$row['appr'].'</td>';
echo "</tr>";
}
}
else
{
 echo "sorry no match found";
 header("Refresh:1; url=../hodsearch.html");
}
$conn->close();
 ?>