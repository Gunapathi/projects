<?php
ob_start();
$con = mysqli_connect('127.0.0.1','root','');
	
	if(!$con)
	{
		echo 'not connected to server';
	}
	if(!mysqli_select_db($con,'one'))
	{
		echo 'No db selected';
	}
$id = $_GET['id1'];
$pass1 = $_GET['pass2'];
$sql = "SELECT id, pass1 FROM `person` WHERE id='$id' AND pass1='$pass1'";
$result = $con->query($sql);
//$rowcount =  mysqli_num_rows($result);
	if(($pass1 == $_GET['pass2'])&&($id == $_GET['id1']))
	{
		if($result->num_rows > 0)
		{	
			echo "YOU ARE LOGGED IN";
			header("Refresh:1; url=../test.html");
		}
		else
		{
		 echo "SORRY NO MATCH FOUND ON DATABASE";
		 header("Refresh:1; url=../login.html");
		}
	}
	else
	{
		echo 'CHECK YOUR USERNAME AND PASSWORD';
		}
$con->close();
?>
