<?php
	$con = mysqli_connect('127.0.0.1','root','');
	
	if(!$con)
	
	{
		echo 'not connected to server';
	}
	if(!mysqli_select_db($con,'one'))
	{
		echo 'No db selected';	
	}
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$id = $_POST['id'];
	$dep = $_POST['dep'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];
	$pass1 = $_POST['pass1'];
	$pass2 = $_POST['pass2'];
	
			if($pass1==$pass2)
			{
			$sql = "INSERT INTO person(fname,lname,id,dep,email,phno,pass1,pass2) VALUES ('$fname','$lname','$id','$dep','$email','$phno','$pass1','$pass2')";
			
				if(!mysqli_query($con,$sql))
				{
					echo 'YOUR ACCOUNT IS NOT-REGISTERED IN DATABASE';
					header("Refresh:1; url=../index.html");
				}
				else
				{
					echo 'YOUR ACCOUNT IS REGISTERED IN DATABASE';
					header("Refresh:1; url=../login.html");
				}
			}
			else
			{
				echo 'CHECK YOUR PASSWORD';
				header("Refresh:1; url=../index.html");
			}
?>
