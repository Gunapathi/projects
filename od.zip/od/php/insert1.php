<?php
	$con = mysqli_connect('127.0.0.1','root','');
	
	
	if(!$con)
	{
		echo 'not connected to server';
	}
	if(!mysqli_select_db($con,'two'))
	{
		echo 'No db selected';	
	}
	$fname = $_POST['fname'];
	$id = $_POST['id'];
	$email = $_POST['email'];
	$phno = $_POST['phno'];
	$pass1 = $_POST['pass1'];
	$pass2 = $_POST['pass2'];

	
			if($pass1==$pass2)
			{
			$sql = "INSERT INTO person(fname,id,email,phno,pass1,pass2) VALUES ('$fname','$id','$email','$phno','$pass1','$pass2')";
			
				if(!mysqli_query($con,$sql))
				{
					echo 'YOUR ACCOUNT REGISTRATION IS NOT-COMPLETED';
					header("Refresh:1; url=../index1.html");
				}
				else
				{
					echo 'YOUR ACCOUNT REGISTRATION IS COMPLETED';
					header("Refresh:1; url=../login1.html");
				}
					
			}
			else
			{
				echo 'CHECK YOUR PASSWORD';
			}

?>

