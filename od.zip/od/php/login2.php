<?php
ob_start();
$con = mysqli_connect('127.0.0.1','root','');
	
	if(!$con)
	
	{
		echo 'not connected to server';
	}
	
	if(!mysqli_select_db($con,'hod'))
	{
		echo 'No db selected';	
	}
	
$uname = $_GET['uname'];
$pass = $_GET['pass'];
$sql = "SELECT `uname`, `pass` FROM `person` WHERE uname='$uname' AND pass='$pass'";
$result = $con->query($sql);
//$rowcount =  mysqli_num_rows($result);
	if(($pass == $_GET['pass'])&&($uname == $_GET['uname']))
	{
		if($result->num_rows > 0)
		{
		echo 'YOU ARE LOGED IN';
		header("Refresh:1; url=../hod.html");
		}
		else
		{
		 echo "CHECK YOUR USERNAME AND PASSWORD";
		header("Refresh:1; url=../login2.html");
		}
	}
	else
	{
		echo 'CHECK YOUR USERNAME AND PASSWORD';
	}
$con->close();
?>
