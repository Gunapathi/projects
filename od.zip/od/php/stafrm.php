<?php
	$con = mysqli_connect('127.0.0.1','root','');
	
	
	if(!$con)
	
	{
		echo 'not connected to server';
	}
	
	if(!mysqli_select_db($con,'one'))
	{
		echo 'No db selected';	
	}

	$fname = $_POST['fname'];
	$id = $_POST['id'];
	$degree = $_POST['degree'];
	$dep = $_POST['dep'];
	$od = $_POST['od'];
	$clgname = $_POST['clgname'];
	$dtfrm = $_POST['dtfrm'];
	$dtto = $_POST['dtto'];
	$reqod = $_POST['reqod'];
	$ws = $_POST['ws'];
	$ppt = $_POST['ppt'];
	$tevent = $_POST['tevent'];
	$ntevent = $_POST['ntevent'];
	$conf = $_POST['conf'];
	$plink = $_POST['plink'];
		
	
			$sql = "INSERT INTO `stafrm`(`fname`, `id`, `degree`, `dep`, `od`, `clgname`, `dtfrm`, `dtto`, `reqod`, `ws`, `ppt`, `tevent`, `ntevent`, `conf`, `plink`) VALUES ('$fname','$id','$degree','$dep','$od','$clgname','$dtfrm','$dtto','$reqod','$ws','$ppt','$tevent','$ntevent','$conf','$plink')";
			
				if(!mysqli_query($con,$sql))
				{
					echo 'YOUR OD FORM IS NOT-SUBMITTED';
				}
				else
				{
					echo 'YOUR OD FORM IS SUBMITTED';
				}
				header("Refresh:1; url=../login.html");
						
?>

