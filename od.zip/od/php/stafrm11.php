<?php
	$con = mysqli_connect('127.0.0.1','root','');
	
	
	if(!$con)
	
	{
		echo 'not connected to server';
	}
	
	if(!mysqli_select_db($con,'one'))
	{
		echo 'No db selected';	
	}
	
	$regno = $_POST['regno'];
	$dtfrm = $_POST['dtfrm'];
	$dtto = $_POST['dtto'];
	$appr = $_POST['appr'];
	
			$sql = "INSERT INTO `appr`(`regno`, `dtfrm`, `dtto`, `appr`) VALUES ('$regno','$dtfrm','$dtto','$appr')";
			
				if(!mysqli_query($con,$sql))
				{
					echo 'YOUR OD FORM IS NOT-SUBMITTED';
					header("Refresh:1; url=../stafrm1.html");
				}
				else
				{
					echo 'YOUR OD FORM IS SUBMITTED';
					header("Refresh:1; url=../stafrm1.html");
				}
						

?>

