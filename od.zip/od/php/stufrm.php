<?php
	$con = mysqli_connect('127.0.0.1','root','');
	
	
	if(!$con)
	
	{
		echo 'not connected to server';
	}
	
	if(!mysqli_select_db($con,'two'))
	{
		echo 'No db selected';	
	}
	
	$fname = $_POST['fname'];
	$id = $_POST['id'];
	$degree = $_POST['degree'];
	$dep = $_POST['dep'];
	$year = $_POST['year'];
	$sec = $_POST['sec'];
	$batch = $_POST['batch'];
	$od = $_POST['od'];
	$tname = $_POST['tname'];
	$clgname = $_POST['clgname'];
	$dtfrm = $_POST['dtfrm'];
	$dtto = $_POST['dtto'];
	$reqod = $_POST['reqod'];
	$ws = $_POST['ws'];
	$ppt = $_POST['ppt'];
	$tevent = $_POST['tevent'];
	$ntevent = $_POST['ntevent'];
	$conf = $_POST['conf'];
	$sport = $_POST['sport'];
	$plink = $_POST['plink'];
		
	
			$sql = "INSERT INTO `stufrm1`(`fname`, `id`, `degree`, `dep`, `year`, `sec`, `batch`, `od`, `tname`, `clgname`, `dtfrm`, `dtto`, `reqod`, `ws`, `ppt`, `tevent`, `ntevent`, `conf`, `sport`, `plink`) VALUES ('$fname','$id','$degree','$dep','$year','$sec','$batch','$od','$tname','$clgname','$dtfrm','$dtto','$reqod','$ws','$ppt','$tevent','$ntevent','$conf','$sport','$plink')";
			
				if(!mysqli_query($con,$sql))
				{
					echo 'YOUR OD FORM IS NOT-SUBMITTED';
					header("Refresh:1; url=../stufrm.html");
				}
				else
				{
					echo 'YOUR OD FORM IS SUBMITTED';
					header("Refresh:1; url=../login1.html");
				}
					;	

?>

