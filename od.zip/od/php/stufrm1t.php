<?php
ob_start();
$con = mysqli_connect('127.0.0.1','root','');
	
	if(!$con)
	
	{
		echo 'not connected to server';
	}
	if(!mysqli_select_db($con,'two'))
	{
		echo 'No db selected';	
	}
$id = $_GET['id'];
$pass1 = $_GET['pass1'];
$sql = "SELECT id, pass1 FROM `person` WHERE id='$id' AND pass1='$pass1'";
$result = $con->query($sql);
//$rowcount =  mysqli_num_rows($result);
	if(($pass1 == $_GET['pass1'])&&($id == $_GET['id']))
	{
		if($result->num_rows > 0)
		{
		echo 'YOU ARE LOGED IN';
		//header("Refresh:1; url=../stufrm.html");
		}
		else
		{
		 echo "CHECK YOUR USERNAME AND PASSWORD";
		 //header("Refresh:1; url=../login1.html");
		}
	}
	else
	{
		echo 'CHECK YOUR USERNAME AND PASSWORD';
	}
$con->close();
?>
