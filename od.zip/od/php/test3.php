<?php
 
$conn = mysqli_connect('127.0.0.1','root','');
	
	
	if(!$conn)
	{
		echo 'not connected to server';
	}
	
	if(!mysqli_select_db($conn,'two'))
	{
		echo 'No db selected';	
	}


$id = $_POST['id'];
$confi = $_POST['confi'];
 
$sql = "INSERT INTO `stufrm1`(`confi`) VALUES ('$confi')";
$result = $conn->query($sql);
//$rowcount =  mysqli_num_rows($result);
	
	if($id == $_POST['id'])
	{
		if(1==1)
		{	
			echo "ADDED";
			//header("Refresh:1; url=../test.html");
		}
		else
		{
		 echo "SORRY";
		 //header("Refresh:1; url=../login.html");
		}
	}
	else
	{
		echo 'CHECK YOUR USERNAME AND PASSWORD';
		}
$conn->close();
 ?>